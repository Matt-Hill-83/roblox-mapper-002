import DataGridPage from '@/datagrid/page';

export default function Home() {
  return <DataGridPage />;
} 